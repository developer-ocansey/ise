
<?php
include_once 'api/_config.php';
if(isset($_POST['login-submit']))
{
	$email = $_POST['email'];
	$passwd = $_POST['password'];
	
	$crud->login($email,$passwd);
	
}
elseif(isset($_POST['register-submit']))
{	$username = $_POST['username'];
	$email = $_POST['email'];
	$passwd = $_POST['password'];
	$userstype = $_POST['userstype'];
	$crud->register($username,$email,$passwd,$userstype);
  header('location:index.php?success');
	
}
else{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Freelance</title>
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" media="screen">    
	<link rel="stylesheet" type="text/css" href="asset/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="asset/css/custom.css">
	<script type="text/javascript" src="asset/js/jquery.js"></script>
	<script type="text/javascript" src="asset/js/bootstrap.js"></script>
	<script type="text/javascript" src="asset/js/angular.js"></script>
</head>
<body ng-app="myApp" ng-controller="freelanceCtl">

 <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">FREELANCE</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
         <form class="navbar-form navbar-right">
            <div class="form-group">
              <input type="text" placeholder="Find Freelancers" class="form-control">
            </div>
             
             </form>
             <button type="button" class="navbar-form navbar-right btn btn-success btn-md learn" data-toggle="modal" data-target="#myModal">Account </button>


          <a href="learn.html" class="navbar-form navbar-right btn btn-success learn" data-toggle="modal" data-target="#Modalworks">How it works</a>
        </div><!--/.navbar-collapse -->
      </div>
    </nav>
    
<?php
if(isset($_GET['failure']))
{
  ?>
    <div class="container">
  <div class="alert alert-warning">
    <strong>SORRY!</strong><p> You Entered Wrong Login Details!</p>
  </div>
  </div>
    <?php

}

?>

<?php
if(isset($_GET['success']))
{
  ?>
    <div class="container">
  <div class="alert alert-warning">
    <strong>Success!</strong><p> You Successfully Registered Please Login!</p>
  </div>
  </div>
    <?php
    
}

?>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
       
      		<div class="container">
	<div class="row">
		
           <div id="custom-search-input">
           <h2>Find Professionals</h2>
                            <div class="input-group col-md-12">
                                <input type="text" class="  search-query form-control" placeholder="Search" />
                                <span class="input-group-btn">
                                    <button class="btn btn-danger" type="button">
                                        <span class=" glyphicon glyphicon-search"></span>
                                    </button>
                                </span>
                            </div>
                        </div>
	</div>
</div>

        <!-- <p><a class="btn btn-primary btn-lg" href="#" role="button">Get Started</a></p>-->
      </div>
    </div>

    <div class="container">
      <!-- Example row of columns -->
      <div class="row">
      	<h4>POPULAR CATEGORY</h4>
        <div class="col-md-2 col-sm-4">
        	<div class=" card categories ">
        		<h4>Caterer</h4>
        	</div>
           
        </div>
            <div class="col-md-2 col-sm-4">
  			<div class=" card categories ">
        		<h4>plumbers</h4>
        	</div>
        </div>
        <div class="col-md-2 col-sm-4">
      	<div class=" card categories ">
        		<h4>carpenter</h4>
        	</div>     
        </div>
          <div class="col-md-2 col-sm-4">
			<div class=" card categories ">
        		<h4>Driver</h4>
        	</div>           
        </div>
          <div class="col-md-2 col-sm-4">
           <div class=" card categories ">
        		<h4>Event Planner</h4>
        	</div>
        </div>
          <div class="col-md-2 col-sm-4">
			<div class=" card categories ">
        		<h4>home tutors</h4>
        	</div>           
        </div>
      </div>

      <div class="row container">
      
  
	<div class="row processed">
	<div class=" col-sm-6container">
	<div class="process">
    <div class="process-row">
        <div class="process-step">
            <button type="button" class="btn btn-default btn-circle" ><i class="fa fa-user fa-3x"></i></button>
            <p>Personal data</p>
        </div>
        <div class="process-step">
            <button type="button" class="btn btn-default btn-circle" ><i class="fa fa-comments-o fa-3x"></i></button>
            <p>We confirm you</p>
        </div>
        <div class="process-step">
            <button type="button" class="btn btn-default btn-circle" ><i class="fa fa-thumbs-up fa-3x"></i></button>
            <p>Tiger comes</p>
        </div> 
         <div class="process-step">
            <button type="button" class="btn btn-success btn-circle" ><i class="fa fa-eur fa-3x"></i></button>
            <p>You Pay</p>
        </div> 
    </div>
</div>
    </div>

	</div>
	
<hr>
<div>
<h4>TESTIMONIES</h4>
<div class="container content"> 
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel"> 
<!-- Indicators --> 
<ol class="carousel-indicators"> 
<li data-target="#carousel-example-generic" data-slide-to="0" class="active">
	
</li> <li data-target="#carousel-example-generic" data-slide-to="1"></li> 
<li data-target="#carousel-example-generic" data-slide-to="2"></li> 
</ol> <!-- Wrapper for slides --> 
<div class="carousel-inner"> 
<div class="item active"> 
<div class="row"> 
<div class="col-xs-12"> 
<div class="thumbnail adjust1"> 
<div class="col-md-2 col-sm-2 col-xs-12"> 
<img class="media-object img-rounded img-responsive" src="http://lorempixel.com/100/100/people/9/"> </div> 
<div class="col-md-10 col-sm-10 col-xs-12"> 
<div class="caption"> <p class="text-info lead adjust2">I can't wait to test this out.</p>
 <p><span class="glyphicon glyphicon-thumbs-up"></span> This is a testimonial window. Feedback of user can be displayed here.</p> 
 <blockquote class="adjust2"> <p>Abhijit Goswami</p> <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i>
  www.example1.com</cite></small> </blockquote> </div> </div> </div> </div> </div> </div> 
  <div class="item"> 
  <div class="row"> 
  <div class="col-xs-12"> 
  <div class="thumbnail adjust1"> 
  <div class="col-md-2 col-sm-2 col-xs-12"> 
  <img class="media-object img-rounded img-responsive" src="http://placehold.it/100"> 
  </div> <div class="col-md-10 col-sm-10 col-xs-12">
  <div class="caption"> <p class="text-info lead adjust2">I can't wait to test this out.</p>
   <p><span class="glyphicon glyphicon-thumbs-up"></span> This is a testimonial window. Feedback of user can be displayed here.</p>
    <blockquote class="adjust2"> <p>Abhijit Goswami</p> 
    <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> www.example2.com</cite></small>
     </blockquote>
      </div>
       </div> 
       </div>
        </div>
         </div>
          </div> 
          <div class="item"> 
           <div class="row"> 
            <div class="col-xs-12"> 
             <div class="thumbnail adjust1"> 
          	<div class="col-md-2 col-sm-2 col-xs-12"> 
          	<img class="media-object img-rounded img-responsive" src="http://placehold.it/100"> 
          </div> <div class="col-md-10 col-sm-10 col-xs-12"> <div class="caption"> 
          <p class="text-info lead adjust2">I can't wait to test this out.</p> 
          <p><span class="glyphicon glyphicon-thumbs-up"></span> This is a testimonial window. Feedback of user can be displayed here.</p> <blockquote class="adjust2"> 
          <p>Abhijit Goswami</p> 
          <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> www.example3.com</cite></small>
           </blockquote> 
           </div> 
            </div> 
             </div> 
              </div> 
               </div> 
                 </div> 
                  </div> <!-- Controls --> 
          <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"> 
             <span class="glyphicon glyphicon-chevron-left"></span>
              </a> 
               <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"> 
                <span class="glyphicon glyphicon-chevron-right"></span> 
              </a> 
           </div> 
            </div>	
 </div>

      <hr>

      <footer>
        <p>&copy; 2016 Ocansey, Inc.</p>
      </footer>
    </div> <!-- /container -->

<script type="text/javascript">
	
</script>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Account</h4>
      </div>
      <div class="modal-body">
    <div class="text-center"><h4><b>Log In</b></h4></div>
                                <form id="ajax-login-form" action="" method="post" role="form" autocomplete="on">
                                    <div class="form-group">
                                        <label for="username">Email</label>
                                        <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="email"  required="" autocomplete="on">
                                    </div>

                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password" required="" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-xs-7">
                                                <input type="checkbox" tabindex="3" name="remember" id="remember">
                                                <label for="remember"> Remember Me</label>
                                            </div>
                                            <div class="col-xs-5 pull-right">
                                                <input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-success" value="Log In">
                                            </div>
                                        </div>
                                    </div>
                                    </form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal" data-toggle="modal" data-target="#Modalregister">Registers</button>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="Modalregister" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><b>Account</b></h4>
      </div>
      <div class="modal-body"> <div class="text-center">
      		
      		<div class="text-center"><h3><b>Register</b></h3></div>
								<form id="ajax-register-form" action="" method="post" role="form" autocomplete="off">
									<div class="form-group">
										<input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username"  required="">
									</div>
									<div class="form-group">
										<input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email Address" required="">
									</div>
									<div class="form-group">
										<input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password" required="">
									</div>
									<div class="form-group">
										<input type="password" name="password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password" required="">
									</div>
									 <input type="hidden" class="hide" name="userstype" id="token" value="user">
									<div class="form-group">
										<div class="row">
											<div class="col-xs-6 col-xs-offset-3">
												<input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-info" value="Register Now">
											</div>
										</div>
									</div>
                                   </form>
                            </div>

      </div>
 	</div>
    </div>
  </div>
</div>

<div class="modal fade" id="Modalworks" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><b>How It Works</b></h4>
      </div>
      <div class="modal-body"> <div class="text-center">
 		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
 		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
 		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
 		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
 		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
 		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
 			<br />
 			<br />
 			<br />
 		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
 		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
 		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
 		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
 		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
 		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
 			<br />
 			<br />
 			<br />
 		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
 		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
 		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
 		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
 		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
 		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Get Started</button>
      </div>
    </div>
  </div>
</div>

</body>
</html>
<?php } ?>